'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function Register(){
  const router = useRouter()
  const [error, setError] = useState('')
  async function onSubmit(e: React.FormEvent<HTMLFormElement>){
    e.preventDefault()
    const form = e.currentTarget as HTMLFormElement
    const email = (form.elements.namedItem('email') as HTMLInputElement).value
    const password = (form.elements.namedItem('password') as HTMLInputElement).value
    const res = await fetch('/api/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password }) })
    if(res.ok) router.push('/auth/login')
    else setError((await res.json()).error || 'Failed')
  }
  return (
    <main className="mx-auto max-w-md px-6 py-16">
      <h1 className="text-3xl font-bold">Create your account</h1>
      <form className="mt-8 space-y-4" onSubmit={onSubmit}>
        <input name="email" type="email" required placeholder="you@example.com" className="w-full border rounded-md px-3 py-2" />
        <input name="password" type="password" required placeholder="password" className="w-full border rounded-md px-3 py-2" />
        <button className="inline-flex rounded-md bg-black px-4 py-2 text-white">Sign Up</button>
      </form>
      {error && <p className="mt-3 text-red-600 text-sm">{error}</p>}
    </main>
  )
}
