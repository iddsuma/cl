export default function About(){
  return (
    <main className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="text-3xl font-bold">About</h1>
      <p className="mt-4 text-slate-700 max-w-2xl">This corrected starter reproduces a modern UGC‑video tool layout with neutral branding. Replace this copy with your mission and differentiators.</p>
    </main>
  )
}
