export default function Pricing(){
  const tiers = [
    { name: 'Starter', price: 'Free', features: ['Basic templates', 'Watermarked exports'] },
    { name: 'Pro', price: '$19/mo', features: ['All templates', '1080p exports', 'Priority queue'] },
    { name: 'Business', price: '$79/mo', features: ['Teams', 'Brand kit', 'Priority support'] },
  ]
  return (
    <main className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="text-3xl font-bold">Pricing</h1>
      <div className="grid gap-6 md:grid-cols-3 mt-8">
        {tiers.map(t => (
          <div key={t.name} className="border rounded-lg p-6">
            <div className="font-semibold text-xl">{t.name}</div>
            <div className="text-3xl font-bold mt-2">{t.price}</div>
            <ul className="mt-4 space-y-2 text-sm text-slate-700 list-disc list-inside">
              {t.features.map(f => <li key={f}>{f}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </main>
  )
}
