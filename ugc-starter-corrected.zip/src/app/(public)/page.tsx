import Link from 'next/link'

export default function Home() {
  return (
    <main className="mx-auto max-w-5xl px-6 py-20">
      <h1 className="text-4xl sm:text-6xl font-bold">Create high‑converting UGC ads in minutes</h1>
      <p className="mt-6 text-lg text-slate-700">Choose a template, add your product details, and generate ready‑to‑share videos—no filming required.</p>
      <div className="mt-8 flex gap-4">
        <Link href="/auth/register" className="inline-flex items-center rounded-md bg-black px-5 py-3 text-white">Start Creating</Link>
        <Link href="/how-it-works" className="inline-flex items-center rounded-md border px-5 py-3">See how it works</Link>
      </div>
    </main>
  )
}
