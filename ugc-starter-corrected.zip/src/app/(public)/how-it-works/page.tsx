export default function HIW(){
  const steps = [
    { n: 1, title: 'Describe your product', desc: 'Upload an image and key details.' },
    { n: 2, title: 'Pick your vibe', desc: 'Choose from Unboxing, Review, Lifestyle and more.' },
    { n: 3, title: 'Customize & fine‑tune', desc: 'Edit script, adjust tone, pick a voice.' },
    { n: 4, title: 'Generate & download', desc: 'Get your ad in minutes—ready to share.' },
  ]
  return (
    <main className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="text-3xl font-bold">How it works</h1>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mt-8">
        {steps.map(s => (
          <div key={s.n} className="border rounded-lg p-6">
            <div className="text-sm text-slate-500">Step {s.n}</div>
            <div className="mt-2 font-medium">{s.title}</div>
            <div className="text-sm text-slate-600 mt-1">{s.desc}</div>
          </div>
        ))}
      </div>
    </main>
  )
}
