'use client'
import { useState } from 'react'

export default function Contact(){
  const [status, setStatus] = useState<'idle'|'sent'|'error'>('idle')

  async function submit(formData: FormData){
    const res = await fetch('/api/contact', { method:'POST', body: formData })
    setStatus(res.ok ? 'sent' : 'error')
  }

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="text-3xl font-bold">Contact</h1>
      <form className="mt-8 space-y-4" action={submit}>
        <input name="name" required placeholder="Your name" className="w-full border rounded-md px-3 py-2" />
        <input type="email" name="email" required placeholder="you@example.com" className="w-full border rounded-md px-3 py-2" />
        <textarea name="message" required placeholder="How can we help?" className="w-full border rounded-md px-3 py-2 h-36" />
        <button className="inline-flex rounded-md bg-black px-4 py-2 text-white">Send</button>
      </form>
      {status==='sent' && <p className="mt-4 text-green-600">Thanks! We'll get back to you.</p>}
      {status==='error' && <p className="mt-4 text-red-600">Something went wrong.</p>}
    </main>
  )
}
