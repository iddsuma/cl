# UGC Starter (Corrected Flat ZIP)

This ZIP is structured so that **package.json** and the **src/**, **prisma/**
folders are at the **root** of the archive. You can upload this ZIP directly to
**Vercel → New Project → Import → Upload** without changing the Root Directory.

## Quick start
```bash
pnpm i   # or npm/yarn
cp .env.example .env
# set DATABASE_URL and NEXTAUTH_SECRET
npx prisma generate
npx prisma migrate dev --name init
pnpm dev
# open http://localhost:3000
```

### Deploy to Vercel
- Import the ZIP directly (no Git required)
- Ensure framework is detected as **Next.js**
- Set env vars: `NEXTAUTH_SECRET`, `DATABASE_URL`, `NEXTAUTH_URL`
- Deploy
```
