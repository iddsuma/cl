export function PricingTable() {
  const tiers = [
    { name: 'Starter', price: 'Free', features: ['Basic templates', 'Watermarked exports', 'Email support'] },
    { name: 'Pro', price: '$19/mo', features: ['All templates', '1080p exports', 'Priority queue'] },
    { name: 'Business', price: '$79/mo', features: ['Teams', 'Brand kit', 'Priority support'] },
  ]
  return (
    <section className="py-20">
      <div className="mx-auto max-w-6xl px-6">
        <h2 className="text-3xl font-bold">Pricing</h2>
        <p className="mt-2 text-slate-600 max-w-2xl">Choose a plan that fits your production needs.</p>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {tiers.map(t => (
            <div key={t.name} className="rounded-lg border p-6">
              <div className="font-semibold text-xl">{t.name}</div>
              <div className="text-3xl font-bold mt-2">{t.price}</div>
              <ul className="mt-4 space-y-2 text-sm text-slate-700 list-disc list-inside">
                {t.features.map(f => <li key={f}>{f}</li>)}
              </ul>
              <button className="mt-6 inline-flex items-center rounded-md bg-brand px-4 py-2 text-white">Choose {t.name}</button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
