export function HowItWorks() {
  const steps = [
    { n: 1, title: 'Describe your product', desc: 'Upload an image and key details.' },
    { n: 2, title: 'Pick your vibe', desc: 'Choose from Unboxing, Review, Lifestyle and more.' },
    { n: 3, title: 'Customize & fine‑tune', desc: 'Edit script, adjust tone, pick a voice.' },
    { n: 4, title: 'Generate & download', desc: 'Get your ad in minutes—ready to share.' },
  ]
  return (
    <section className="py-20" id="how-it-works">
      <div className="mx-auto max-w-6xl px-6">
        <h2 className="text-3xl font-bold">How it works</h2>
        <p className="mt-2 text-slate-600 max-w-2xl">From product to video in four simple steps.</p>
        <div className="mt-10 grid gap-6 md:grid-cols-4">
          {steps.map(s => (
            <div key={s.n} className="rounded-lg border p-6">
              <div className="text-brand font-semibold">Step {s.n}</div>
              <div className="mt-2 font-medium">{s.title}</div>
              <div className="text-sm text-slate-600 mt-1">{s.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
