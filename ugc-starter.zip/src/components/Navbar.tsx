'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const links = [
  { href: '/how-it-works', label: 'How it Works' },
  { href: '/pricing', label: 'Pricing' },
  { href: '/about', label: 'About' },
  { href: '/contact', label: 'Contact' },
]

export function Navbar() {
  const pathname = usePathname()
  return (
    <header className="border-b bg-white/70 backdrop-blur supports-[backdrop-filter]:bg-white/40 sticky top-0 z-50">
      <div className="mx-auto max-w-6xl px-6 py-4 flex items-center justify-between">
        <Link href="/" className="font-semibold text-xl">UGC<span className="text-brand">Starter</span></Link>
        <nav className="hidden md:flex items-center gap-6">
          {links.map(l => (
            <Link key={l.href} href={l.href} className={pathname===l.href? 'text-brand font-medium':'text-slate-600 hover:text-slate-900'}>
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/auth/login" className="text-slate-700 hover:text-slate-900">Login</Link>
          <Link href="/auth/register" className="inline-flex items-center rounded-md bg-brand px-4 py-2 text-white hover:opacity-90">Sign Up</Link>
        </div>
      </div>
    </header>
  )
}
