import Link from 'next/link'
export function Footer() {
  return (
    <footer className="border-t">
      <div className="mx-auto max-w-6xl px-6 py-10 grid gap-6 md:grid-cols-3">
        <div>
          <div className="font-semibold text-lg">UGCStarter</div>
          <p className="text-sm text-slate-600 mt-2">AI-powered UGC ad starter. Replace with your brand.</p>
        </div>
        <div className="text-sm space-y-2">
          <Link href="/how-it-works" className="block text-slate-700 hover:text-slate-900">How it Works</Link>
          <Link href="/pricing" className="block text-slate-700 hover:text-slate-900">Pricing</Link>
          <Link href="/about" className="block text-slate-700 hover:text-slate-900">About</Link>
          <Link href="/contact" className="block text-slate-700 hover:text-slate-900">Contact</Link>
        </div>
        <div className="text-sm text-slate-600">© {new Date().getFullYear()} Your Company. All rights reserved.</div>
      </div>
    </footer>
  )
}
