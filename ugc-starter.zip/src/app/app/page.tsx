export default function AppHome(){
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <h1 className="text-3xl font-bold">Welcome back</h1>
      <p className="mt-2 text-slate-700">This is a placeholder dashboard. Add your generator, templates and assets here.</p>
    </div>
  )
}
