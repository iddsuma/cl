'use client'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useState } from 'react'

export default function Login(){
  const router = useRouter()
  const [error, setError] = useState('')
  async function onSubmit(e: React.FormEvent<HTMLFormElement>){
    e.preventDefault()
    const form = e.currentTarget as HTMLFormElement
    const email = (form.elements.namedItem('email') as HTMLInputElement).value
    const password = (form.elements.namedItem('password') as HTMLInputElement).value
    const res = await signIn('credentials', { redirect:false, email, password })
    if(res?.ok) router.push('/app')
    else setError('Invalid credentials')
  }
  return (
    <div className="mx-auto max-w-md px-6 py-16">
      <h1 className="text-3xl font-bold">Welcome back</h1>
      <form className="mt-8 space-y-4" onSubmit={onSubmit}>
        <input name="email" type="email" required placeholder="you@example.com" className="w-full border rounded-md px-3 py-2" />
        <input name="password" type="password" required placeholder="password" className="w-full border rounded-md px-3 py-2" />
        <button className="inline-flex rounded-md bg-brand px-4 py-2 text-white">Login</button>
      </form>
      {error && <p className="mt-3 text-red-600 text-sm">{error}</p>}
    </div>
  )
}
