import { HowItWorks } from '@/components/HowItWorks'
export default function HIW(){
  return (
    <>
      <div className="mx-auto max-w-6xl px-6 py-16">
        <h1 className="text-4xl font-bold">From idea to ad in minutes</h1>
        <p className="mt-3 text-slate-700 max-w-2xl">Follow this simple 4‑step process to generate influencer‑style ad creatives without filming.</p>
      </div>
      <HowItWorks />
    </>
  )
}
