export default function About(){
  return (
    <div className="mx-auto max-w-6xl px-6 py-16">
      <h1 className="text-4xl font-bold">About</h1>
      <p className="mt-4 text-slate-700 max-w-2xl">This starter reproduces a modern UGC‑video tool layout using neutral content and branding. Replace this copy with your mission and differentiators.</p>
    </div>
  )
}
