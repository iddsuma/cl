import Link from 'next/link'
import { HowItWorks } from '@/components/HowItWorks'

export default function Home() {
  return (
    <div>
      <section className="relative isolate">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <div className="max-w-2xl">
            <h1 className="text-4xl sm:text-6xl font-bold">Create high‑converting UGC ads in minutes</h1>
            <p className="mt-6 text-lg text-slate-700">Choose a template, add your product details, and generate ready‑to‑share videos—no filming required.</p>
            <div className="mt-8 flex gap-4">
              <Link href="/auth/register" className="inline-flex items-center rounded-md bg-brand px-5 py-3 text-white">Start Creating</Link>
              <Link href="/how-it-works" className="inline-flex items-center rounded-md border px-5 py-3">See how it works</Link>
            </div>
          </div>
        </div>
      </section>
      <HowItWorks />
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-6 grid gap-6 md:grid-cols-3">
          {[1,2,3].map(i => (
            <div key={i} className="border rounded-lg p-6">
              <div className="font-semibold">Template {i}</div>
              <p className="text-sm text-slate-600 mt-2">Short description about what this template is great for.</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
