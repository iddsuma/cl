# UGC Starter (UGCPadi-like)

This is a starter repository that reproduces the public structure of ugcpadi.com (hero, how-it-works, pricing, about, contact, auth), with a clean Next.js 14 + Tailwind + Prisma stack and a basic dashboard shell. **Branding, copy, and assets are placeholders** so you can insert your own brand.

## Tech
- Next.js 14 (App Router)
- Tailwind CSS
- Prisma + PostgreSQL
- NextAuth (credentials provider)

## Getting started

```bash
pnpm i   # or npm/yarn
cp .env.example .env
# edit DATABASE_URL and NEXTAUTH_SECRET
npx prisma generate
npx prisma migrate dev --name init
pnpm dev
```

Open http://localhost:3000

### Optional: Payments later
There are placeholders for Paystack/Flutterwave API routes you can fill when you’re ready.

## Project structure
```
src/
  app/
    (public)/
      page.tsx                # Home
      about/page.tsx
      pricing/page.tsx
      how-it-works/page.tsx
      contact/page.tsx
    auth/
      login/page.tsx
      register/page.tsx
    app/page.tsx              # Dashboard shell (post-login)
    api/
      contact/route.ts        # Contact form handler
      auth/[...nextauth]/route.ts
  components/
  lib/
  styles/
prisma/schema.prisma
```

## Notes
- Replace colors in `tailwind.config.ts` and the logo text in `Navbar`.
- Copy is generic; tailor it to your product.

MIT License
